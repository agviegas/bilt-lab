import * as BUI from "@thatopen/ui";
import * as OBC from "@thatopen/components";

BUI.Manager.registerComponents();

const grid = document.getElementById("grid") as BUI.Grid;
grid.layouts = {
  main: `
  "c-panels-left viewer" 1fr
  "c-panels-table c-panels-table" minmax(auto, 450px)
  /auto 1fr
  `,
};

grid.layout = "main";

const panel = document.querySelector<BUI.PanelSection>(
  "bim-panel[name='entityAttributes']",
)!;

const leftPanelContainer = grid.getContainer("panels", "left");
leftPanelContainer.append(panel);

const viewport = document.getElementById("viewer-container") as BUI.Viewport;

const components = new OBC.Components();

const worlds = components.get(OBC.Worlds);

const world = worlds.create();
const sceneComponent = new OBC.SimpleScene(components);
sceneComponent.setup();
world.scene = sceneComponent;

const rendererComponent = new OBC.SimpleRenderer(components, viewport);
world.renderer = rendererComponent;

const cameraComponent = new OBC.SimpleCamera(components);
world.camera = cameraComponent;

viewport.addEventListener("resize", () => {
  rendererComponent.resize();
  cameraComponent.updateAspect();
});

components.init();

const grids = components.get(OBC.Grids);
grids.create(world);

const ifcLoader = components.get(OBC.FragmentIfcLoader);
// await ifcLoader.setup();
const file = await fetch("/resources/small.ifc");
const buffer = await file.arrayBuffer();
const typedArray = new Uint8Array(buffer);
const model = await ifcLoader.load(typedArray);
world.scene.three.add(model);
