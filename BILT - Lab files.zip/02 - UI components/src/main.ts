import * as BUI from "@thatopen/ui";

BUI.Manager.registerComponents();

const grid = document.getElementById("grid") as BUI.Grid;
grid.layouts = {
  main: `
  "c-panels-left viewer" 1fr
  "c-panels-table c-panels-table" minmax(auto, 450px)
  /auto 1fr
  `,
};

grid.layout = "main";

const panel = document.querySelector<BUI.PanelSection>(
  "bim-panel[name='entityAttributes']",
)!;

const leftPanelContainer = grid.getContainer("panels", "left");
leftPanelContainer.append(panel);

const viewport = document.getElementById("viewer-container") as BUI.Viewport;